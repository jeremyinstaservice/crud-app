<?php


echo "Thank You for voting, we are grateful";


?>